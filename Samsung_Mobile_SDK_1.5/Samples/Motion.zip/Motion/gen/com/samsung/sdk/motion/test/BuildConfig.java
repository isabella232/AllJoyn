/** Automatically generated file. DO NOT MODIFY */
package com.samsung.sdk.motion.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}