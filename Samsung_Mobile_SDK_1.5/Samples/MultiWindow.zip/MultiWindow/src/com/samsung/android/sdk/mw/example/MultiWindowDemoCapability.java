package com.samsung.android.sdk.mw.example;


import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.samsung.android.sdk.multiwindow.*;


public class MultiWindowDemoCapability extends ListActivity {
	
	private static final int MENU_IS_MULTI_WINDOW_SUPPORT = 0;

	private SMultiWindow mMultiWindow = null;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		String[] mStrings = new String[] {"1. Is MultiWindow Support"};
		
		setListAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, mStrings));
        getListView().setTextFilterEnabled(true);
        
        mMultiWindow = new SMultiWindow();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.multi_window_example, menu);
		return true;
	}

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
    	displayPopup(position);
    }
    
    private void displayPopup(int position) {
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(getTitle(position));
    	builder.setMessage(getDemoResult(position));
    	builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
    		 @Override
    		 public void onClick(DialogInterface dialog, int which) {
    			 dialog.dismiss();
    		 }
    	});
    	builder.show();
    }
    
    private String getTitle(int position) {
    	switch(position) {
	    	case MENU_IS_MULTI_WINDOW_SUPPORT:
				return "Is MultiWindow Support";
    	}
    	
    	return "MultiWindowDemo";
    }
    
    private String getDemoResult(int position) {    	
    	if (mMultiWindow == null) {
    		return null;
    	}

    	switch (position) {
	    	case MENU_IS_MULTI_WINDOW_SUPPORT:
				return Boolean.toString(mMultiWindow.isFeatureEnabled(SMultiWindow.MULTIWINDOW));

    	}
    	
    	
    	return "MultiWindowDemo";
    }
}
