package com.samsung.android.sdk.mw.example;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.samsung.android.sdk.multiwindow.*;


public class MultiWindowDemoFunction extends ListActivity {
	
	private static final int MENU_LAUNCH_MULTI_WINDOW_APP = 0;
	private static final int MENU_IS_NORMAL_WINDOW = 1;
	private static final int MENU_IS_MULTI_WINDOW = 2;
	private static final int MENU_GET_RECTINFO = 3;
	private static final int MENU_GET_ZONEINFO = 4;
	private static final int MENU_NORMAL_WINDOW = 5;
	private static final int MENU_SET_STATE_CHANGE_LISTENER = 6;
	private static final int MENU_RESET_STATE_CHANGE_LISTENER = 7;
	
	private static final int MSG_SHOW_TOAST = 100;
	
	private SMultiWindow mMultiWindow = null;
	private SMultiWindowActivity mMultiWindowActivity = null;
	private List<ResolveInfo> mMultiWindowAppList = null;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		String[] mStrings = new String[] {
									      "1. Launch MultiWindow Application",
										  "2. Is Normal Window", 
                                          "3. Is Multi Window",
                                          "4. Get RectInfo",
                                          "5. Get ZoneInfo",
                                          "6. Normal Window",
                                          "7. Set statechange Listener",
                                          "8. Reset statechange Listener"};
		
		setListAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, mStrings));
        getListView().setTextFilterEnabled(true);
        
        mMultiWindow = new SMultiWindow();
        mMultiWindowActivity = new SMultiWindowActivity(this);
        
 		mMultiWindowAppList = new ArrayList<ResolveInfo>();
 		Intent intent = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
 		List<ResolveInfo> resolveInfos = getPackageManager().queryIntentActivities(intent, PackageManager.GET_RESOLVED_FILTER|PackageManager.GET_META_DATA);
 		
 		for (ResolveInfo r : resolveInfos) {
 			if (r.activityInfo != null && r.activityInfo.applicationInfo.metaData != null) {
 				if (r.activityInfo.applicationInfo.metaData.getBoolean("com.sec.android.support.multiwindow")
 						|| r.activityInfo.applicationInfo.metaData.getBoolean("com.samsung.android.sdk.multiwindow.enable")) {
 					boolean bUnSupportedMultiWinodw = false; 
 					if (r.activityInfo.metaData != null) {
 						String activityWindowStyle = r.activityInfo.metaData.getString("com.sec.android.multiwindow.activity.STYLE");
 		            	if (activityWindowStyle != null) {
 		            		ArrayList<String> activityWindowStyles = new ArrayList<String>(Arrays.asList(activityWindowStyle.split("\\|")));
 		            		if (!activityWindowStyles.isEmpty()) {
	 		                    if (activityWindowStyles.contains("fullscreenOnly")) {
	 		                    	bUnSupportedMultiWinodw = true;
	 		                    }
 		            		}
 		                }
 		            }

 		            if (!bUnSupportedMultiWinodw) {
 		            	mMultiWindowAppList.add(r);
 		            }
 				}
 			}
 		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.multi_window_example, menu);
		return true;
	}

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
    	switch(position) {
    		case MENU_SET_STATE_CHANGE_LISTENER:
    			try {
	    			boolean success = mMultiWindowActivity.setStateChangeListener(new SMultiWindowActivity.StateChangeListener() {
	    				@Override
	    				public void onModeChanged(boolean arg0) {
	    					// TODO Auto-generated method stub
	    					if (arg0) {
	    						Toast.makeText(MultiWindowDemoFunction.this, "MultiWindow Mode is changed to Multi-Window", Toast.LENGTH_LONG).show();
	    					} else {
	    						Toast.makeText(MultiWindowDemoFunction.this, "MultiWindow Mode is changed to Normal-Window", Toast.LENGTH_LONG).show();
	    					}
	    				}
	
	    				@Override
	    				public void onZoneChanged(int arg0) {
	    					// TODO Auto-generated method stub
	    					String zoneInfo = "Free zone";
	    					if (arg0 == SMultiWindowActivity.ZONE_A) {
	    						zoneInfo = "Zone A";
	    					} else if (arg0 == SMultiWindowActivity.ZONE_B) {
	    						zoneInfo = "Zone B";
	    					}
	    					Toast.makeText(MultiWindowDemoFunction.this, "Activity zone info is changed to " + zoneInfo, Toast.LENGTH_LONG).show();
	    				}
	    				
	    				@Override
						public void onSizeChanged(Rect arg0) {
							// TODO Auto-generated method stub
	    					Toast.makeText(MultiWindowDemoFunction.this, "Activity size info is changed to " + arg0, Toast.LENGTH_LONG).show();
						}
	    			});
	    			
	    			if (success) {
	    				Toast.makeText(MultiWindowDemoFunction.this, "Register state change listener", Toast.LENGTH_LONG).show();
	    			} else {
	    				Toast.makeText(MultiWindowDemoFunction.this, "Not supported API ", Toast.LENGTH_LONG).show();
	    			}
	        		
    			} catch(UnsupportedOperationException e) {
    				displayPopup(position);
    			}
        		break;
    		case MENU_RESET_STATE_CHANGE_LISTENER:
    			if (mMultiWindowActivity.setStateChangeListener(null)) {
    				Toast.makeText(MultiWindowDemoFunction.this, "Reset state change listener", Toast.LENGTH_LONG).show();
    			} else {
    				Toast.makeText(MultiWindowDemoFunction.this, "Not supported API ", Toast.LENGTH_LONG).show();
    			}
    			break;
    			
    		case MENU_LAUNCH_MULTI_WINDOW_APP:
    			displayAppList(position);
    			break;
    		
    		case MENU_NORMAL_WINDOW:
    			mMultiWindowActivity.normalWindow();
    			break;
    		
    		default:
    			displayPopup(position);
    	}
    }
    
    private void displayPopup(int position) {
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(getTitle(position));
    	builder.setMessage(getDemoResult(position));
    	builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
    		 @Override
    		 public void onClick(DialogInterface dialog, int which) {
    			 dialog.dismiss();
    		 }
    	});
    	builder.show();
    }
    
    private String getTitle(int position) {
    	switch(position) {
			case MENU_IS_NORMAL_WINDOW:
				return "Is Normal Window";
			
			case MENU_IS_MULTI_WINDOW:
				return "Is Multi Window";
			
			case MENU_GET_RECTINFO:
				return "Get Rect Info";
			
			case MENU_GET_ZONEINFO:
				return "Get Zone Info";
			
			case MENU_NORMAL_WINDOW:
				return "Normal Window";
				
    	}
    	
    	return "MultiWindowDemo";
    }
    
    private String getDemoResult(int position) {    	
    	if (mMultiWindowActivity == null) {
    		return null;
    	}

    	switch (position) {
			case MENU_IS_NORMAL_WINDOW:
				return Boolean.toString(mMultiWindowActivity.isNormalWindow());
			
			case MENU_IS_MULTI_WINDOW:
				return Boolean.toString(mMultiWindowActivity.isMultiWindow());
			
			case MENU_GET_RECTINFO:
				return mMultiWindowActivity.getRectInfo().toString();
			
			case MENU_GET_ZONEINFO:
				int zoneInfo = mMultiWindowActivity.getZoneInfo();
				if (!mMultiWindow.isFeatureEnabled(SMultiWindow.MULTIWINDOW)) {
					return "Zone None";
				}
				if (zoneInfo == SMultiWindowActivity.ZONE_A) {
					return "Zone A";
				} else if (zoneInfo == SMultiWindowActivity.ZONE_B) {
					return "Zone B";
				} else {
					if (mMultiWindowActivity.isMultiWindow()) {
						return "Zone Free";
					} else {
						return "Zone None";
					}
				}
			
			case MENU_NORMAL_WINDOW:

    	}
    	
    	
    	return "MultiWindowDemo";
    }
    
    private void displayAppList(int position) {
    	ArrayList<String> appListLabels = new ArrayList<String>();
    	if (mMultiWindowAppList != null) {
    		int appListCount = mMultiWindowAppList.size();
    		for (int i = 0 ; i < appListCount ; i++) {
    			appListLabels.add((String) mMultiWindowAppList.get(i).loadLabel(getPackageManager()));
    		}
    	}
    	
    	String[] listItems = new String[0]; 
    	listItems = appListLabels.toArray(listItems);
    	AlertDialog.Builder appListDialog = new AlertDialog.Builder(this);
    	appListDialog.setTitle(getTitle(position))
    	.setItems(listItems, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				displayLaunchType(which);
			}
		}).show();
    }
    
    private void displayLaunchType(int appPosition) {
    	final ArrayList<String> launchTypes = new ArrayList<String>();
    	final int selectedApp = appPosition;
    	launchTypes.add("Zone A");
	    launchTypes.add("Zone B");
    	
    	String[] listItems = new String[0]; 
    	listItems = launchTypes.toArray(listItems);
    	AlertDialog.Builder launchTypeDialog = new AlertDialog.Builder(this);
    	launchTypeDialog.setTitle("Select Launch Type")
    	.setItems(listItems, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				String launchType = launchTypes.get(which);
				ResolveInfo selectApp = mMultiWindowAppList.get(selectedApp);
				ComponentInfo selectAppInfo = selectApp.activityInfo != null ? selectApp.activityInfo : selectApp.serviceInfo;
				Intent intent = new Intent(Intent.ACTION_MAIN);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.setComponent(new ComponentName(selectAppInfo.packageName, selectAppInfo.name));
				if ("Zone A".equals(launchType)) {
					SMultiWindowActivity.makeMultiWindowIntent(intent, SMultiWindowActivity.ZONE_A);
				} else if("Zone B".equals(launchType)) {
					SMultiWindowActivity.makeMultiWindowIntent(intent, SMultiWindowActivity.ZONE_B);
				} else {
					return;
				}

				startActivity(intent);
			}
		}).show();
    }
}
