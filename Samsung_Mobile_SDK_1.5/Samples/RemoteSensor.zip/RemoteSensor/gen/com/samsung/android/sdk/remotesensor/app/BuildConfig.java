/** Automatically generated file. DO NOT MODIFY */
package com.samsung.android.sdk.remotesensor.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}