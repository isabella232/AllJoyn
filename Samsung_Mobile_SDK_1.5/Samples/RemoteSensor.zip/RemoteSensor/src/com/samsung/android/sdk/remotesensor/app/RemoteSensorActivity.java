package com.samsung.android.sdk.remotesensor.app;

import com.samsung.android.sdk.SsdkUnsupportedException;

import com.samsung.android.sdk.remotesensor.SrsRemoteSensorManager;
import com.samsung.android.sdk.remotesensor.SrsRemoteSensorManager.EventListener;
import com.samsung.android.sdk.remotesensor.SrsRemoteSensorEvent;
import com.samsung.android.sdk.remotesensor.SrsRemoteSensor;

import com.samsung.android.sdk.remotesensor.Srs;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;

import android.content.Intent;

import android.widget.GridView;
import android.content.res.TypedArray;
import android.content.res.Resources;

import android.app.AlertDialog;
import android.content.DialogInterface;

import android.widget.Toast;

import android.net.Uri;

import java.util.ArrayList;
import java.util.List;


/**
 * This is an example of using Remote Sensor package. This application gets the user activity and
 * Pedometer data. For each type of data. The steps are :
 * 1) Get the remote sensor property => Displays sensor properties like version, type, maximum range, ...
 * 2) Enable getting remote sensor data => The remote sensor data is updated periodically.
 * 3) Stop getting remote sensor data => The remote sensor data is not updated anymore.
 * Pre-condition : Host device(Phone) and Wearable device are paired using Gear Mananger Application.
 */

public class RemoteSensorActivity extends Activity implements EventListener {
	private static final int				NO_OF_SENSORS = 3;
	public static SensorDetailsAdapter		mSensorAdapter = null;

	public static final int					USER_ACTIVITY = 0;
	public static final int					PEDOMETER = 1;
	public static final int					WEARING_STATE = 2;

	public static String []				userActivityValues = {"Unknown State",
													     "Walk",
													     "Run"};

	public static String []				wearingStateValues = {"Not Wearing",
													        "Wearing"};

	static SrsRemoteSensorManager		mServiceManager = null;
	Srs								remoteSensor = null;
	ArrayList<SensorData>				mSensorDetailsList = null;

	List<SrsRemoteSensor>				activitySensorList = null;
	List<SrsRemoteSensor>				pedoSensorList = null;
	List<SrsRemoteSensor>				wearingSensorList = null;

	SrsRemoteSensor					userActivitySensor = null;
	SrsRemoteSensor					pedometerSensor = null;
	SrsRemoteSensor					wearingSensor = null;
/*
	private final static String				GEAR2 = "com.samsung.accessory";
	private final static String				GEAR_FIT = "com.samsung.android.wms";
	private final static String				RS_SERVICE = "com.samsung.android.sdk.remotesensor";
*/

	public static class SensorData {
		public String		mSensorName;
		public String		mSensorDetails;
		public String		mValueName;
		public String		mValue;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_remote_sensor);

		TypedArray a = this.obtainStyledAttributes (R.styleable.gridviewbg1);
		int mGalleryItemBackground = a.getResourceId(
							R.styleable.gridviewbg1_android_galleryItemBackground, 0);
		a.recycle();

		View view = this.getWindow().getDecorView();

		view.setBackgroundColor (mGalleryItemBackground);

		remoteSensor = new Srs();

		try {
			/**
			 * initialize() initialize Remote Sensor package. This needs to be called first.
			 * If the device does not support Remote Sensor, SsdkUnsupportedException is thrown.
			 */
			remoteSensor.initialize (this.getApplicationContext ());
		} catch (SsdkUnsupportedException e) {

			switch (e.getType ()) {
			case SsdkUnsupportedException.LIBRARY_NOT_INSTALLED:
				if (remoteSensor.isFeatureEnabled (Srs.TYPE_REMOTE_SENSOR_SERVICE) == false) {
					Toast.makeText (this, "Install Remote Sensor Service package", Toast.LENGTH_SHORT).show();
					invokeInstallOption (R.string.rss_msg_str);
				}

				if ((remoteSensor.isFeatureEnabled (Srs.TYPE_GEAR_MANAGER) == false) && (remoteSensor.isFeatureEnabled (Srs.TYPE_GEAR_FIT_MANAGER) == false)) {
					Toast.makeText (this, "Install Gear Manager or Gear Fit Manager package", Toast.LENGTH_SHORT).show();
					invokeInstallOption (R.string.manager_msg_str);
				}

				break;

			case SsdkUnsupportedException.LIBRARY_UPDATE_IS_REQUIRED:
				Toast.makeText (this, "Package update is required", Toast.LENGTH_SHORT).show();
				break;

			default:
				Toast.makeText (this, "SsdkUnsupportedException = " + e.getType (), Toast.LENGTH_SHORT).show();
				break;
			}

		} catch (RuntimeException e) {
			Toast.makeText (this, e.getMessage(), Toast.LENGTH_SHORT).show();
		}

		/**
		 * Create instance of SrsRemoteSensorManager.
		 */
		mServiceManager = new SrsRemoteSensorManager (remoteSensor);

		mSensorDetailsList = new ArrayList<SensorData> ();

		Resources	res = getResources();
		SensorData	temp = null;

		for (int index = 0; index < NO_OF_SENSORS; index++) {
			temp = new SensorData ();

			switch (index) {
				case USER_ACTIVITY:
					temp.mSensorName = String.format(res.getString(R.string.user_activity_str));
				break;

				case PEDOMETER:
					temp.mSensorName = String.format(res.getString(R.string.pedometer_str));
				break;

				case WEARING_STATE:
					temp.mSensorName = String.format(res.getString(R.string.wearing_str));
				break;
			}

			temp.mValueName = String.format(res.getString(R.string.value_str));
			temp.mSensorDetails = null;
			temp.mValue = null;

			mSensorDetailsList.add (temp);
		}

		mSensorAdapter = new SensorDetailsAdapter (this, mSensorDetailsList);

		GridView	gridview = (GridView) findViewById (R.id.gridView1);
		gridview.setAdapter (mSensorAdapter);

		gridview.setBackgroundColor (mGalleryItemBackground);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		if (userActivitySensor != null) {
			mServiceManager.unregisterListener (this, userActivitySensor);
		}

		if (pedometerSensor != null) {
			mServiceManager.unregisterListener (this, pedometerSensor);
		}
	}

	private void invokeInstallOption (final int msgID) {

		DialogInterface.OnClickListener	msgClick = new DialogInterface.OnClickListener () {
			@Override
			public void onClick (DialogInterface dialog, int selButton) {
				switch (selButton) {
					case DialogInterface.BUTTON_POSITIVE:
/*
						String	packName = null;

						if (msgID == R.string.manager_msg_str) {
							packName = "market://details?id=" + GEAR2;
						} else if (msgID == R.string.rss_msg_str) {
							packName = "market://details?id=" + RS_SERVICE;
						}

						Intent	intent = new Intent(Intent.ACTION_VIEW, Uri.parse (packName));
						startActivity(intent);

						Uri packageURI = Uri.parse("package:" + getPackageName());
						Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
						uninstallIntent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity (uninstallIntent);

						Intent installIntent = new Intent(Intent.ACTION_VIEW, packageURI);
						startActivity (installIntent);
*/

						Uri packageURI = Uri.parse("package:" + getPackageName());
						Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
						uninstallIntent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity (uninstallIntent);
					break;

					case DialogInterface.BUTTON_NEGATIVE:
						finish ();
					break;
				}
			}
		};

		AlertDialog.Builder	message = new AlertDialog.Builder (this, AlertDialog.THEME_HOLO_DARK);

		message.setMessage (msgID);
		//message.setPositiveButton (R.string.install_str, msgClick);
		//message.setNegativeButton (R.string.cancel_str, msgClick);

		message.setPositiveButton (R.string.uninstall_str, msgClick);
		message.setCancelable (false);

		message.show ();

	}

	public void getPedometerSensorInfo (int position){
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		stopPedometerEvent (position);

		sensorData.mSensorDetails = " ";
		sensorData.mValue = " ";

		/**
		 * getSensorList() gets the remote sensor list. The supported sensor types are :
		 * TYPE_ALL, TYPE_PEDOMETER, TYPE_USER_ACTIVITY
		 */
		pedoSensorList = mServiceManager.getSensorList(SrsRemoteSensor.TYPE_PEDOMETER);
		if ((pedoSensorList != null) && (pedoSensorList.size () > 0)){
			SrsRemoteSensor		sensor;

			sensor = pedoSensorList.get(0);
			sensorData.mSensorDetails = sensor.toString ();

		} else {
			sensorData.mSensorDetails = "Peodometer Sensor is not available";
			sensorData.mValue = " ";
		}
	}

	public void getPedometerEvent (int position) {
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		if ((mServiceManager != null) && (pedoSensorList != null) && (pedoSensorList.size() > 0)){
			Resources		res = getResources();
			boolean			bRet = false;

			pedometerSensor = pedoSensorList.get (0);

			/**
			 * The rate argument set the interval between the successive events. Now there are four values :
			 * SENSOR_DELAY_SLOW, SENSOR_DELAY_NORMAL, SENSOR_DELAY_FAST, SENSOR_DELAY_FASTEST.
			 * The maxBatchReportLatency argument specify the maximum batching time. When the maxBatchReportLatency
			 * is set, the events are batched and delivered later. The unit is microsecond.
			 *
			 * Note :
			 * The maxBatchReportLatency is not supported now. Please set it to zero.
			 * For TYPE_PEDOMETER sensor, the rate argument has no effects now. The interval is fixed as 5 minutes
			 * and it is less than 5 minutes when the pedometer data is already available as  in case that another
			 * application has already registered the TYPE_PEDOMETER sensor. The power of the wearable device was
			 * considered for interval decision. For TYPE_USER_ACTIVITY sensor, the event delay is about 4 to 5
			 * seconds. This value corresponds to 4 to 8 steps and is to prevent a noise.
			 */
			bRet = mServiceManager.registerListener (this, pedometerSensor, SrsRemoteSensorManager.SENSOR_DELAY_NORMAL, 0);
			//bRet = mServiceManager.requestTriggerSensor (this, pedometerSensor);

			if (bRet == false) {
				Toast.makeText (this, "registerListener for pedometer sensor is falied", Toast.LENGTH_SHORT).show();
			} else {
				sensorData.mValueName = String.format (res.getString(R.string.stop_str));

				//Toast.makeText (this, "registerListener for pedometer sensor is success", Toast.LENGTH_SHORT).show();
			}

		} else {
			sensorData.mValue = "Peodometer Sensor is not available";
		}

	}

	public void stopPedometerEvent (int position){
		SrsRemoteSensor	sensor;
		SensorData		sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		if ((mServiceManager != null) && (pedoSensorList != null) && (pedoSensorList.size () > 0)){
			Resources		res = getResources();

			sensorData.mValueName = String.format(res.getString(R.string.value_str));

			sensor = pedoSensorList.get(0);

			mServiceManager.unregisterListener (this, sensor);

		} else {
			sensorData.mValue = "Peodometer Sensor is not available";
		}
	}

	public void getUserActivitySensorInfo (int position){
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		stopUserActivityEvent (position);

		sensorData.mSensorDetails = " ";
		sensorData.mValue = " ";

		/**
		 * getSensorList() gets the remote sensor list. The supported sensor types are :
		 * TYPE_ALL, TYPE_PEDOMETER, TYPE_USER_ACTIVITY
		 */
		activitySensorList = mServiceManager.getSensorList(SrsRemoteSensor.TYPE_USER_ACTIVITY);
		if ((activitySensorList != null) && (activitySensorList.size () > 0)){
			SrsRemoteSensor		sensor;

			sensor = activitySensorList.get(0);
			sensorData.mSensorDetails = sensor.toString ();

		} else {
			sensorData.mSensorDetails = "User Activity Sensor is not available";
			sensorData.mValue = " ";
		}
	}

	public void getUserActivityEvent (int position) {
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		if ((mServiceManager != null) && (activitySensorList != null) && (activitySensorList.size() > 0)){
			Resources		res = getResources();
			boolean			bRet = false;

			userActivitySensor = activitySensorList.get(0);

			/**
			 * The rate argument set the interval between the successive events. Now there are four values :
			 * SENSOR_DELAY_SLOW, SENSOR_DELAY_NORMAL, SENSOR_DELAY_FAST, SENSOR_DELAY_FASTEST.
			 * The maxBatchReportLatency argument specify the maximum batching time. When the maxBatchReportLatency
			 * is set, the events are batched and delivered later. The unit is microsecond.
			 *
			 * Note :
			 * The maxBatchReportLatency is not supported now. Please set it to zero.
			 * For TYPE_PEDOMETER sensor, the rate argument has no effects now. The interval is fixed as 5 minutes
			 * and it is less than 5 minutes when the pedometer data is already available as  in case that another
			 * application has already registered the TYPE_PEDOMETER sensor. The power of the wearable device was
			 * considered for interval decision. For TYPE_USER_ACTIVITY sensor, the event delay is about 4 to 5
			 * seconds. This value corresponds to 4 to 8 steps and is to prevent a noise.
			 */
			bRet = mServiceManager.registerListener (this, userActivitySensor, SrsRemoteSensorManager.SENSOR_DELAY_NORMAL, 0);
			//bRet = mServiceManager.requestTriggerSensor (this, userActivitySensor);

			if (bRet == false) {
				Toast.makeText (this, "registerListener for user activity sensor is falied", Toast.LENGTH_SHORT).show();
			} else {
				sensorData.mValueName = String.format(res.getString(R.string.stop_str));

				//Toast.makeText (this, "registerListener for user activity sensor is success", Toast.LENGTH_SHORT).show();
			}

		} else {
			sensorData.mValue = "User Activity Sensor is not available";
		}

	}

	public void stopUserActivityEvent (int position){
		SrsRemoteSensor		sensor;
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		if ((mServiceManager != null) && (activitySensorList != null) && (activitySensorList.size () > 0)){
			Resources		res = getResources();

			sensorData.mValueName = String.format(res.getString(R.string.value_str));

			sensor = activitySensorList.get(0);

			mServiceManager.unregisterListener (this, sensor);

		} else {
			sensorData.mValue = "User Activity Sensor is not available";
		}
	}

	public void getWearingStateSensorInfo (int position){
		SensorData			sensorData = null;

		sensorData = mSensorDetailsList.get (position);

		sensorData.mSensorDetails = " ";
		sensorData.mValue = " ";

		/**
		 * getSensorList() gets the remote sensor list. The supported sensor types are :
		 * TYPE_ALL, TYPE_PEDOMETER, TYPE_USER_ACTIVITY
		 */
		wearingSensorList = mServiceManager.getSensorList(SrsRemoteSensor.TYPE_WEARING_STATE);
		if ((wearingSensorList != null) && (wearingSensorList.size () > 0)){
			SrsRemoteSensor		sensor;

			sensor = wearingSensorList.get(0);
			sensorData.mSensorDetails = sensor.toString ();

		} else {
			sensorData.mSensorDetails = "Wearing State Sensor is not available";
			sensorData.mValue = " ";
		}
	}

	public void getWearingStateEvent (int position) {

		if ((mServiceManager != null) && (wearingSensorList != null) && (wearingSensorList.size() > 0)){
			boolean	bRet = false;

			wearingSensor = wearingSensorList.get (0);

			bRet = mServiceManager.requestTriggerSensor (this, wearingSensor);
			//bRet = mServiceManager.registerListener (this, wearingSensor, SrsRemoteSensorManager.SENSOR_DELAY_NORMAL, 0);
			if (bRet == false) {
				Toast.makeText (this, "requestTriggerSensor for wearing state sensor is falied", Toast.LENGTH_SHORT).show();
			} else {
				//Toast.makeText (this, "requestTriggerSensor for wearing state sensor is success", Toast.LENGTH_SHORT).show();
			}

		} else {
			SensorData			sensorData = null;

			sensorData = mSensorDetailsList.get (position);
			sensorData.mValue = "Wearing State Sensor is not available";
		}

	}

	@Override
	protected void onResume(){
		super.onResume();

		if (userActivitySensor != null) {
			mServiceManager.registerListener (this, userActivitySensor, SrsRemoteSensorManager.
									SENSOR_DELAY_NORMAL, 0);
		}

		if (pedometerSensor != null) {
			mServiceManager.registerListener (this, pedometerSensor, SrsRemoteSensorManager.
									SENSOR_DELAY_NORMAL, 0);
		}
	}

	@Override
	protected void onPause(){
		super.onPause();

		if (userActivitySensor != null) {
			mServiceManager.unregisterListener (this, userActivitySensor);
		}

		if (pedometerSensor != null) {
			mServiceManager.unregisterListener (this, pedometerSensor);
		}
	}


	/**
	 * Called when the accuracy of a sensor has changed.
	 *
	 * Note : For sensor type TYPE_PEDOMETER and TYPE_USER_ACTIVITY, onAccuracyChanged() method is not supported.
	 */
	@Override
	public void onAccuracyChanged(SrsRemoteSensor sensor, int accuracy){

	}

	/**
	 * Called when sensor values have changed.
	 * onSensorValueChanged() is called periodically or when there is an event. (ex. Start to walk, start to run).
	 * Even though SrsRemoteSensorEvent.values data type is float, integer value is contained for sensor type
	 * TYPE_PEDOMETER. And the possible values for sensor type TYPE_USER_ACTIVITY are :
	 * 1 (start to walk), 2 (start to run).
	 *
	 */
	@Override
	public void onSensorValueChanged(final SrsRemoteSensorEvent event){

		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				SensorData			sensorData = null;

				if (event.sensor.getType() == SrsRemoteSensor.TYPE_PEDOMETER) {
					sensorData = mSensorDetailsList.get (PEDOMETER);

					sensorData.mValue = "Step Count : (" + Float.toString(event.values[0]) + ")";
				} else if (event.sensor.getType() == SrsRemoteSensor.TYPE_USER_ACTIVITY) {
					String		data = null;
					int			index = (int)event.values [0];

					if ((index >= 0 ) && (index <= 2 )){
						data = userActivityValues [index];
					} else {
						data = "Invalid Data : " + index;
					}

					sensorData = mSensorDetailsList.get (USER_ACTIVITY);

					sensorData.mValue = "Activity : (" + data + ")";
				} else if (event.sensor.getType() == SrsRemoteSensor.TYPE_WEARING_STATE) {
					String		data = null;
					int			index = (int)event.values[0];

					if ((index == 0 ) || (index == 1 )){
						data = wearingStateValues [index];
					} else {
						data = "Invalid Data : " + index;
					}

					sensorData = mSensorDetailsList.get (WEARING_STATE);

					sensorData.mValue = "Wearing State : (" + data + ")";
				}

				mSensorAdapter.notifyDataSetChanged ();
			}
		});

	}

	/**
	 * Called when sensor is disabled in case of device disconnected.
	 */
	@Override
	public void onSensorDisabled(SrsRemoteSensor sensor){
		/**
		 *  TO DO: the routine to treat this exception.
		 */
	}
}

