package com.samsung.android.sdk.remotesensor.app;

import com.samsung.android.sdk.remotesensor.app.RemoteSensorActivity.SensorData;

import android.app.Activity;
import android.view.LayoutInflater;
import android.widget.TextView;
import android.widget.Button;
import android.widget.BaseAdapter;
import android.view.ViewGroup;
import android.view.View;
import android.content.res.TypedArray;
import android.content.res.Resources;

import java.util.ArrayList;
import java.util.List;

public class SensorDetailsAdapter extends BaseAdapter {
	public static Activity					mActivity;
	private static List<SensorData>		mSelSensorList = null;
	private LayoutInflater				mInflator = null;
	public static int						mItemBackground;
	public static RemoteSensorActivity		mRSActivity = null;

	public SensorDetailsAdapter (RemoteSensorActivity activity, ArrayList<SensorData> sensorList) {
		View				convertView;

		mRSActivity = activity;

		mActivity = activity;
		mInflator = activity.getLayoutInflater();
		mSelSensorList = sensorList;

		convertView = mInflator.inflate(R.layout.layout_sensor_details, null);

		TypedArray a = mActivity.obtainStyledAttributes (R.styleable.gridviewbg1);
		mItemBackground = a.getResourceId(
							R.styleable.gridviewbg1_android_galleryItemBackground, 0);
		a.recycle();

		convertView.setBackgroundColor (mItemBackground);
	}

	@Override
	public int getCount () {
		if (mSelSensorList != null) {
			return mSelSensorList.size ();
		}

		return 0;
	}

	@Override
	public String getItem (int position) {
		return null;
	}

	@Override
	public long getItemId (int position) {
		return position;
	}

	private static class SensorDetailsView {
		public Button	 	mSensorNameBt;
		public TextView 	mSensorDetailsTxt;
		public Button	 	mSensorValBt;
		public TextView 	mSensorValTxt;

		SensorDetailsView (View convertView) {
			mSensorNameBt = (Button) convertView.findViewById(R.id.bt_sensor_name);
			if (mSensorNameBt != null) {
				mSensorNameBt.setOnClickListener (new View.OnClickListener() {
					public void onClick(View view) {
						Integer				position = (Integer) view.getTag ();

						switch (position) {
							case RemoteSensorActivity.USER_ACTIVITY:
								mRSActivity.getUserActivitySensorInfo (position);
							break;

							case RemoteSensorActivity.PEDOMETER:
								mRSActivity.getPedometerSensorInfo (position);
							break;

							case RemoteSensorActivity.WEARING_STATE:
								mRSActivity.getWearingStateSensorInfo (position);
							break;
						}

						RemoteSensorActivity.mSensorAdapter.notifyDataSetChanged();
					}
				});
			}

			mSensorDetailsTxt = (TextView) convertView.findViewById(R.id.txt_sensor_details);
			mSensorValBt = (Button) convertView.findViewById(R.id.bt_value);
			if (mSensorValBt != null) {
				mSensorValBt.setOnClickListener (new View.OnClickListener() {
					public void onClick(View view) {
						Integer			position = (Integer) view.getTag ();
						Resources		res = mActivity.getResources();
						SensorData		sensorData = null;

						sensorData = mSelSensorList.get (position);

						switch (position) {
							case RemoteSensorActivity.USER_ACTIVITY:
								if (sensorData.mValueName.equals (String.format(res.getString(R.string.value_str)))) {
									mRSActivity.getUserActivityEvent (position);
								} else {
									mRSActivity.stopUserActivityEvent (position);
								}
							break;

							case RemoteSensorActivity.PEDOMETER:
								if (sensorData.mValueName.equals (String.format(res.getString(R.string.value_str)))) {
									mRSActivity.getPedometerEvent (position);
								} else {
									mRSActivity.stopPedometerEvent (position);
								}
							break;

							case RemoteSensorActivity.WEARING_STATE:
								mRSActivity.getWearingStateEvent (position);
							break;
						}

						RemoteSensorActivity.mSensorAdapter.notifyDataSetChanged();
					}
				});
			}

			mSensorValTxt = (TextView) convertView.findViewById(R.id.txt_value);
		}
	}

	// create a new ImageView for each item referenced by the Adapter
	public View getView (int position, View convertView, ViewGroup parent) {
		SensorDetailsView	sensorView;
		View				base = convertView;
		SensorData		sensorData = null;

		if (mSelSensorList != null) {
			sensorData = mSelSensorList.get (position);
		}

		if (base == null) {
			base = mInflator.inflate(R.layout.layout_sensor_details, null);
			sensorView = new SensorDetailsView (base);
			base.setTag (sensorView);
		} else {
			sensorView = (SensorDetailsView) base.getTag ();
		}

		if ((sensorView != null) && (sensorData != null) ) {
			sensorView.mSensorNameBt.setTag (Integer.valueOf (position));
			sensorView.mSensorValBt.setTag (Integer.valueOf (position));

			if (sensorData.mSensorName != null) {
				sensorView.mSensorNameBt.setText (sensorData.mSensorName);
			}

			if (sensorData.mSensorDetails != null) {
				sensorView.mSensorDetailsTxt.setText (sensorData.mSensorDetails);
			}

			if (sensorData.mValueName != null) {
				sensorView.mSensorValBt.setText (sensorData.mValueName);
			}

			if (sensorData.mValue != null) {
				sensorView.mSensorValTxt.setText (sensorData.mValue);
			}

		}

		return base;
	}

}

