/*    
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.   
 * All rights reserved.   
 *   
 * Redistribution and use in source and binary forms, with or without   
 * modification, are permitted provided that the following conditions are   
 * met:   
 *   
 *     * Redistributions of source code must retain the above copyright   
 *        notice, this list of conditions and the following disclaimer.  
 *     * Redistributions in binary form must reproduce the above  
 *       copyright notice, this list of conditions and the following disclaimer  
 *       in the documentation and/or other materials provided with the  
 *       distribution.  
 *     * Neither the name of Samsung Electronics Co., Ltd. nor the names of its  
 *       contributors may be used to endorse or promote products derived from  
 *       this software without specific prior written permission.  
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS  
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT  
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT  
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE  
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.samsung.accessory.sagalleryconsumer.ui;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.samsung.accessory.sagalleryconsumer.R;
import com.samsung.accessory.sagalleryconsumer.backend.SASmartViewConsumerImpl;
import com.samsung.accessory.sagalleryconsumer.backend.SASmartViewConsumerImpl.ImageListReceiver;
import com.samsung.accessory.sagalleryconsumer.backend.SASmartViewConsumerImpl.LocalBinder;
import com.samsung.accessory.sagalleryconsumer.datamodel.ImageStructure;
import com.samsung.android.sdk.accessory.SAPeerAgent;
import com.samsung.android.sdk.accessory.SASocket;

public class GalleryConsumerActivity extends Activity implements
		OnClickListener, ImageListReceiver {

	public static final String TAG = "SmartViewConsumerActivity";

	public static final int MSG_THUMBNAIL_RECEIVED = 1986;
	public static final int MSG_IMAGE_RECEIVED = 1987;
	public static final int INITIAL_IMAGE_INDEX = -1;

	SASmartViewConsumerImpl mBackendService = null;
	List<ImageStructure> mDTBListReceived = null;
	ImageStructure mImage = null;
	String mDownscaledImage = "";
	int mNextIndex = INITIAL_IMAGE_INDEX;
	int mIndextb1 = INITIAL_IMAGE_INDEX, mIndextb2 = INITIAL_IMAGE_INDEX,
			mIndextb3 = INITIAL_IMAGE_INDEX;
	boolean mIsBound = false;
	boolean mReConnect = false;
	//SAPeerAgent mPeerAgent;
	public static final int MSG_INITIATE_CONNECTION = 6;

	Button mAdd;
	Button mFetch;
	Button mNext;
	Button mClose;
	//Button mPrev;
	ImageView mTb1;
	ImageView mTb2;
	ImageView mTb3;

	private static Object mListLock = new Object();
	
	 /**
     * 
     * @author amit.s5
     *
     */
	private ServiceConnection mConnection = new ServiceConnection() {
		public void onServiceConnected(ComponentName className, IBinder service) {
			LocalBinder binder = (LocalBinder) service;
			mBackendService = binder.getService();
			mBackendService.registerImageReciever(GalleryConsumerActivity.this);
			mIsBound = true;
			mBackendService.findPeers();
			Log.i(TAG, "Service attached to " + className.getClassName());
		}

		public void onServiceDisconnected(ComponentName className) {
			// This is called when the connection with the service has been
			// unexpectedly disconnected - process crashed.
			Log.e(TAG,"Gallery Service Disconnected");
			mBackendService = null;
			mIsBound = false;
		}
	};

	 /**
     * 
     * @author amit.s5
     *
     */
	private void clearThumbnails() {
		Log.d(TAG, "clearThumbnails new  response  has arrived");
		mIndextb1 = INITIAL_IMAGE_INDEX;
		mIndextb2 = INITIAL_IMAGE_INDEX;
		mIndextb3 = INITIAL_IMAGE_INDEX;
		mNextIndex = INITIAL_IMAGE_INDEX;
		mTb1.setImageResource(R.drawable.ic_launcher);
		mTb2.setImageResource(R.drawable.ic_launcher);
		mTb3.setImageResource(R.drawable.ic_launcher);
	}

	
	 /**
     * 
     * @author amit.s5
     *
     */
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		Log.d(TAG, "clearThumbnails new  response  has arrived  :"+mReConnect);
		if(mReConnect == true && mBackendService != null ){
			mBackendService.findPeers();
		}
		super.onResume();
	}


    /**
     * 
     * @param savedInstanceState
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.d(TAG, "onCreate conusmer activity");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_easy_gallery_consumer);

		// Bind to the consumer service on create itself
		doBindServiceToConsumerService();
		mAdd = (Button) findViewById(R.id.button1);
		mAdd.setOnClickListener(this);

		mFetch = (Button) findViewById(R.id.button2);
		mFetch.setOnClickListener(this);
		
		mClose = (Button) findViewById(R.id.button3);
		mClose.setOnClickListener(this);
		
		mNext = (Button) findViewById(R.id.button4);
		mNext.setOnClickListener(this);

		mTb1 = (ImageView) findViewById(R.id.imageView4);
		mTb1.setOnClickListener(this);
		mTb2 = (ImageView) findViewById(R.id.imageView2);
		mTb2.setOnClickListener(this);
		mTb3 = (ImageView) findViewById(R.id.imageView3);
		mTb3.setOnClickListener(this);

	}

	 /**
     * 
     * @author amit.s5
     *
     */
	protected void onDestroy() {
		Log.i(TAG, "onDestroy");
		closeConnection();
		doUnbindService();

		super.onDestroy();

	}

	 /**
     * 
     * @author amit.s5
     *
     */
	void doBindServiceToConsumerService() {
		Log.i(TAG, "doBindServiceToConsumerService");
		mIsBound = bindService(
				new Intent(this, SASmartViewConsumerImpl.class), mConnection,
				Context.BIND_AUTO_CREATE);

	}

	 /**
     * 
     * @author amit.s5
     *
     */
	void doUnbindService() {
		if (mIsBound == true) {
			unbindService(mConnection);
			mIsBound = false;
		}
	}

	 /**
     * 
     * @author amit.s5
     *
     */
	void closeConnection() {
		if (mIsBound == true) {
			mBackendService.closeConnection();

		}
	}

    /**
     * 
     * @param menu
     * @return boolean
     */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.easy_gallery_consumer, menu);
		return true;
	}

    /**
     * 
     * @param menu
     * @return boolean
     */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
//		Intent myintent = new Intent(this, EnterIPActivity.class);
//		startActivity(myintent);
		return super.onOptionsItemSelected(item);
	}

    /**
     * 
     * @param v
     */
	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.button1: {
			if (mIsBound) {

				mBackendService.findPeers();
			}

		}
			break;

		case R.id.button2: {
			Log.d(TAG, " ask  provider to  fetch thumbnails now");
			if (mIsBound) {
				requestThumbnails();
			}
		}
			break;
			
		case R.id.button3: {
			Log.d(TAG, " close service connection");
			if (mIsBound) {
				closeConnection();
			}
		}
			break;
			
		case R.id.button4: {
			Log.d(TAG, " NEXT  Series of thumbnails button pressed");
			if (mIsBound) {
				requestNext();
			}
		}
			break;

		case R.id.imageView2: {
			Log.d(TAG, " imageView2 pressed");
			requestImage(mIndextb2);
		}
			break;

		case R.id.imageView3: {
			Log.d(TAG, " imageView3 pressed");
			requestImage(mIndextb3);
		}
			break;

		case R.id.imageView4: {
			Log.d(TAG, " imageView4 pressed");
			requestImage(mIndextb1);
		}
			break;

		}

	}

	/**
     * 
     * @author amit.s5
     *
     */
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {

			if (msg.what == MSG_THUMBNAIL_RECEIVED) {
				Log.i(TAG, "Received Thumbnails now updating UX");
				clearThumbnails();
				handleReceivedThumbnails();
			} else if (msg.what == MSG_IMAGE_RECEIVED) {
				Log.i(TAG, "Received downscaled image now updating UX");

				handleRecievedImage();

			}
		}
	};

	 /**
     * 
     * @author amit.s5
     *
     */
	private void requestThumbnails() {
		Log.d(TAG, "Requesting initial list of Thumbnails");
		mBackendService.requestThumbNail(INITIAL_IMAGE_INDEX);

		mNextIndex = INITIAL_IMAGE_INDEX;
	}

	 /**
     * 
     * @author amit.s5
     *
     */
	private void requestNext() {
		Log.d(TAG, " send  next  request with id to service with = "
				+ mNextIndex);

		if (mNextIndex != -1)
			mBackendService.requestThumbNail(mNextIndex);
		else
			requestThumbnails();
	}

    /**
     * 
     * @param index
     */
	private void requestImage(int index) {

		Log.d(TAG, " send  image  rqst to service");

		if (index != INITIAL_IMAGE_INDEX) {
			Log.d(TAG, " send  downscale image  request to service with id = "
					+ index);

			mBackendService.requestImage(index);
		} else {
			Log.d(TAG,
					"no thumbnails found on consumer side to request for image");
		}
	}

    /**
     * 
     * @param img
     */
	public void onImageReceived(ImageStructure img) {

		mImage = img;
		Message msg = Message.obtain();
		msg.what = MSG_IMAGE_RECEIVED;
		mHandler.sendMessage(msg);
	}

    /**
     * 
     * @return boolean
     */
	private boolean handleRecievedImage() {

		// parse the structure and render on Image VIEW
		Log.d(TAG, "Update  Ui  with  downscaled image named = "
				+ mImage.mDisplayname);
		mDownscaledImage = mImage.mData;
		Log.i(TAG, "base 64 encoded string length received is : "
				+ mDownscaledImage.length());
		byte[] decodedstream = Base64.decode(mDownscaledImage, Base64.NO_WRAP);
		Log.i(TAG, "decoded byte  stream size = : " + decodedstream.length);
		Bitmap bitmap = BitmapFactory.decodeByteArray(decodedstream, 0,
				decodedstream.length);

		// full.setImageBitmap(bitmap);

		// try new full screen approach
		final AlertDialog.Builder thumbDialog = new AlertDialog.Builder(
				GalleryConsumerActivity.this);
		ImageView thumbView = new ImageView(GalleryConsumerActivity.this);
		thumbView.setMinimumWidth(320);
		thumbView.setMinimumWidth(240);

		thumbView.setBackgroundResource(00000000);
		if (bitmap != null) {
			Log.i(TAG, "downscaled bitmap size = " + bitmap.getByteCount());
			Log.i(TAG, "downscaled bitmap Width = " + bitmap.getWidth());
			Log.i(TAG, "downscaled bitmap Height = " + bitmap.getHeight());
			thumbView.setImageBitmap(bitmap);
		}
		else
			Log.e(TAG,"Bitmap  recieved is  invalid");
		LinearLayout layout = new LinearLayout(GalleryConsumerActivity.this);
		layout.setOrientation(LinearLayout.VERTICAL);
		layout.addView(thumbView);
		thumbDialog.setView(layout);
		thumbDialog.show();

		Toast.makeText(getApplicationContext(), mImage.mDisplayname,
				Toast.LENGTH_LONG).show();

		return true;
	}

    /**
     * 
     * @param uListReceived
     */
	@Override
	public void onThumbnailsReceived(List<ImageStructure> uListReceived) {
		synchronized (mListLock) {
		// consumer can use this list to hold previous thumbnails as cache
		Log.d(TAG,"onThumbnailsReceived Enter");
		mDTBListReceived = uListReceived;
		Message msg = Message.obtain();
		msg.what = MSG_THUMBNAIL_RECEIVED;
		mHandler.sendMessage(msg);
		}
	}

    /**
     * 
     */
	private boolean handleReceivedThumbnails() {
		Log.d(TAG,"handleReceivedThumbnails Enter");
		synchronized (mListLock) {
		int size = mDTBListReceived.size();
		Log.i(TAG, "TB list is = " + size);
		if (!mDTBListReceived.isEmpty()) {
			// last  elements  id  for refrence
			try{
				mNextIndex = Integer.parseInt(mDTBListReceived.get(size - 1).mId);
			}catch(IndexOutOfBoundsException  e){
				Log.e(TAG,"invalid index to get in arraylist");
				e.printStackTrace();
			}
			Log.i(TAG, "index  for image is choosen as = " + mNextIndex);
			while (size > 0) {
				ImageStructure thb1 = mDTBListReceived.get(size - 1);
				// tb1.setImageBitmap(bm);
				Log.i(TAG, "list  entry  = " + size
						+ " : id of the image been = " + thb1.mId);
				Log.i(TAG, "base 64 encoded string length received is : "
						+ thb1.mData.length());
				byte[] decodedstream = Base64
						.decode(thb1.mData, Base64.NO_WRAP);
				Log.i(TAG, "decode byte  stream size = : "
						+ decodedstream.length);

				Bitmap bitmap = BitmapFactory.decodeByteArray(decodedstream, 0,
						decodedstream.length);

				if (bitmap != null) {
					Log.i(TAG,
							"bitmap size to be rendered = " + bitmap.getByteCount());
					Log.i(TAG, "bitmap Width to be rendered = " + bitmap.getWidth());
					Log.i(TAG,
							"bitmap Height to be rendered = " + bitmap.getHeight());
					switch (size) {
					case 3: {
						mTb1.setImageBitmap(bitmap);
						mIndextb1 = Integer.parseInt(thb1.mId);
					}
						break;
					case 2: {
						mTb2.setImageBitmap(bitmap);
						mIndextb2 = Integer.parseInt(thb1.mId);
					}
						break;
					case 1: {
						mTb3.setImageBitmap(bitmap);
						mIndextb3 = Integer.parseInt(thb1.mId);
					}
						break;
					}
				} else {
					Log.e(TAG, "bitmap decodingfor  base64  string  failed");
				}
				size--;
			}
		}
		return true;
		}
	}

    /**
     * 
     * @param uRemoteAgent
     */
	@Override
	public void onPeerFound(SAPeerAgent uRemoteAgent) {

		Log.d(TAG, "onPeerFound enter");
		if (uRemoteAgent != null) {
			if (mIsBound = true) {
				Log.d(TAG, "peer  agent is found  and  try to  connect");
				mBackendService.establishConnection(uRemoteAgent);
			} else
				Log.d(TAG, "Service not bound !!!");
		} else {
			Log.d(TAG, "no peers  are  present  tell the UI");
			Toast.makeText(getApplicationContext(), R.string.NoPeersFound,
					Toast.LENGTH_LONG).show();
		}

	}


    /**
     * 
     * @param errorcode
     */
	@Override
	public void onServiceConnectionLost(int errorcode) {
		Log.d(TAG, "onServiceConnectionLost  enter with error value "+errorcode);
		if(errorcode == SASocket.CONNECTION_LOST_DEVICE_DETACHED)
			mReConnect = true;
	}
	
}