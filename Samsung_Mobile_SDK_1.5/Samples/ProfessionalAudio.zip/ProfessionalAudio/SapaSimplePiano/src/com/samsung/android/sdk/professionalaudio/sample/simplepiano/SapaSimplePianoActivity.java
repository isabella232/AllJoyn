package com.samsung.android.sdk.professionalaudio.sample.simplepiano;

import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.professionalaudio.Sapa;
import com.samsung.android.sdk.professionalaudio.SapaProcessor;
import com.samsung.android.sdk.professionalaudio.SapaService;

public class SapaSimplePianoActivity extends Activity {
	
	private SapaService mService;
	private SapaProcessor mProcessor;
	
	private static final String TAG = "SapaSimplePiano";

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sapa_simple_piano);
		
		try{
			(new Sapa()).initialize(this);
			mService = new SapaService();
			mService.start(SapaService.START_PARAM_DEFAULT_LATENCY);
			
			List<SapaService.PluginInfo> list = mService.getPluginList();
			Iterator<SapaService.PluginInfo> iter = list.iterator();
			while(iter.hasNext()){
				SapaService.PluginInfo info = iter.next();
				if(info.getName().contentEquals("SapaPiano")){
					mProcessor = new SapaProcessor(this, info, new SapaProcessor.StatusListener() {
						
						@Override
						public void onKilled() {
							Log.v(TAG, "SapaSimplePiano will be closed. because of the SapaProcessor was closed.");
							mService.stop(true);
							finish();
						}
					});
					
				}
			}
			if(mProcessor == null){
				Toast.makeText(this, "The SapaPiano plugin does not exist. Please install the SapaFluidSynthPlugin", Toast.LENGTH_LONG).show();
				finish();
				return;
			}

			mService.register(mProcessor);

			mProcessor.sendCommand("START");

			mProcessor.activate();
			
		}catch (SsdkUnsupportedException e){
			e.printStackTrace();
			Toast.makeText(this, "Not support Professional Audio package", Toast.LENGTH_LONG).show();
			finish();
			return;
		}catch (IllegalArgumentException e){
			e.printStackTrace();
			Toast.makeText(this, "Error - invalid arguments. please check the log", Toast.LENGTH_LONG).show();
			finish();
			return;
		}catch (InstantiationException e){
			e.printStackTrace();
			Toast.makeText(this, "Error. please check the log", Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		

		((Button)findViewById(R.id.play_sound_c1)).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// play sound c3
				final int noteC3 = 60;
				final int velocity = 90;
				mProcessor.sendCommand(String.format("PLAY %d %d", noteC3, velocity));
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(mService != null){
			if(mProcessor != null){
				mService.unregister(mProcessor);
			}
			mService.stop(false);
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

}
