SapaSimpleClient

Overview :
----------

This is a sample of S Professional Audio package in Samsung Mobile SDK.
When you press the "PLAY" button, It plays a simple sine wave sound like keytone.
To stop the sound, Press the Back key.
When you press the Home key, The sound will be continues.


Limitations : 
-------------

After playing a sound, Why the sound still playing when you swipe the app out 
of the task list(the recent apps list)?
Answer) 
The sound will be played in the processing module. It's a new process which 
is not the process that you swipe out.
So, it is playing. 

Why doesn't the framework do anything when you swipe the app out of the task list?
Answer)
It's impossible to do something when you swipe. 
Because the Android just kill the process without any notifications or events. 


More details:
-------------
See the content of the programming guide.


