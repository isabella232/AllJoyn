package com.samsung.android.sdk.professionalaudio.plugin.fluidsynthplugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

public class Breceiver extends BroadcastReceiver {

	private static final String TAG = "SapaFluidSynthPlugin";
	
	@Override
	public void onReceive(Context context, Intent intent) {
		//Toast.makeText(context, "Copying a sound font", Toast.LENGTH_LONG).show();
		copyAssets(context);
	}
	
	private void copyAssets(Context context) {
		final String mSoundFontDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/";
		String[] files = null;
		String mkdir = null ;
		AssetManager assetManager = context.getAssets();
		try 
		{
			files = assetManager.list("");
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage());
			e.printStackTrace();
			return;
		}

		for(int i=0; i<files.length; i++) 
		{
			InputStream in = null;
			OutputStream out = null;
			try
			{
				File tmp = new File(mSoundFontDir, files[i]);
				if(!tmp.exists())
				{
					in = assetManager.open(files[i]);
				}

				if(in == null)
				{
					//Log.d(TAG, "file is already exist");
					continue;
				}

				mkdir = mSoundFontDir;

				File mpath = new File(mkdir);

				if(! mpath.isDirectory()) 
				{
					mpath.mkdirs();
				}

				out = new FileOutputStream(mSoundFontDir + files[i]);          

				final byte[] buffer = new byte[1024];               
				int read;
				//Log.d(TAG, "Start copy files");	            
				while((read = in.read(buffer)) != -1)
				{
					out.write(buffer, 0, read);
				}      

				in.close();
				in = null;
				out.flush();
				out.close();
				out = null;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}      
		}
		
	}
}
