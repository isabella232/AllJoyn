package com.samsung.android.sdk.professionalaudio.plugin.fluidsynthplugin;

import android.app.Activity;
import android.os.Bundle;

public class SapaFluidSynthPluginHelpActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sapa_fluidsynth_plugin_help);
	}
}
