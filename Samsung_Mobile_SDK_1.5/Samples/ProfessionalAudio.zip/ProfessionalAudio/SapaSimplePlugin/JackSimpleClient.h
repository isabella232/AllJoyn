
#ifndef ANDROID_JACK_SIMPLE_CLIENT_H
#define ANDROID_JACK_SIMPLE_CLIENT_H

#include <jack/jack.h>

#include "IJackClientInterface.h"
#include "APACommon.h"

namespace android {

class JackSimpleClient: public IJackClientInterface {
	public:
		JackSimpleClient();
		virtual ~JackSimpleClient();
		int setUp(int argc, char *argv[]);
		int tearDown();
		int activate();
		int deactivate();
		int transport(TransportType type);
		int sendMidi(char* midi);
	private:
		static void signal_handler(int sig);
		static int process (jack_nframes_t nframes, void *arg);
		static void jack_shutdown (void *arg);
		static unsigned int getFileSize(FILE **file);
		static char *getFileBuffer(FILE **file, unsigned int fileSize);
		static unsigned int readWaveFileToMemory(const char path[], char **buffer);
};

};

#endif // ANDROID_JACK_SIMPLE_CLIENT_H

