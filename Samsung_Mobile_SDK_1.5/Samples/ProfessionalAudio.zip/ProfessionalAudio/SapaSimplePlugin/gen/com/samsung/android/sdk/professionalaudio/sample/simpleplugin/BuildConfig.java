/** Automatically generated file. DO NOT MODIFY */
package com.samsung.android.sdk.professionalaudio.sample.simpleplugin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}