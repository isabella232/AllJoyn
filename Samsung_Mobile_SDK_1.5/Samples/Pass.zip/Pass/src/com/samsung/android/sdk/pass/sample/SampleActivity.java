package com.samsung.android.sdk.pass.sample;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;
import com.samsung.android.sdk.pass.sample.R;

public class SampleActivity extends Activity {

    private SpassFingerprint mSpassFingerprint;
    private Spass mSpass;
    private Context mContext;
    private ListView mListView;
    private List<String> mItemArray = new ArrayList<String>();
    private ArrayAdapter<String> mListAdapter;
    private boolean onReadyIdentify = false;
    boolean isFeatureEnabled = false;

    private SpassFingerprint.IdentifyListener listener = new SpassFingerprint.IdentifyListener() {
        @Override
        public void onFinished(int eventStatus){
            log("identify finished : reason=" + getEventStatusName(eventStatus));
            onReadyIdentify = false;

            if (eventStatus == SpassFingerprint.STATUS_AUTHENTIFICATION_SUCCESS
             || eventStatus == SpassFingerprint.STATUS_AUTHENTIFICATION_PASSWORD_SUCCESS) {
            	log("onFinished() : Authentification Success for identify");
            }
            else {
            	log("onFinished() : Authentification Fail for identify");
            }
        }

        @Override
        public void onReady() {
            log("identify state is ready");
        }

        @Override
        public void onStarted() {
            log("User touched fingerprint sensor!");
        }
    };
    
    private SpassFingerprint.RegisterListener mRegisterListener = new SpassFingerprint.RegisterListener() {
		
		@Override
		public void onFinished() {
			log("RegisterListener.onFinished()");
			
		}
	};
    private static String getEventStatusName(int eventStatus) {
        switch (eventStatus) {
        case SpassFingerprint.STATUS_AUTHENTIFICATION_SUCCESS:
            return "STATUS_AUTHENTIFICATION_SUCCESS";
        case SpassFingerprint.STATUS_AUTHENTIFICATION_PASSWORD_SUCCESS:
            return "STATUS_AUTHENTIFICATION_PASSWORD_SUCCESS";
        case SpassFingerprint.STATUS_TIMEOUT_FAILED:
            return "STATUS_TIMEOUT";
        case SpassFingerprint.STATUS_SENSOR_FAILED:
            return "STATUS_SENSOR_ERROR";
        case SpassFingerprint.STATUS_USER_CANCELLED:
            return "STATUS_USER_CANCELLED";
        case SpassFingerprint.STATUS_QUALITY_FAILED:
            return "STATUS_QUALITY_FAILED";
        case SpassFingerprint.STATUS_AUTHENTIFICATION_FAILED:
        default:
            return "STATUS_AUTHENTIFICATION_FAILED";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mContext = this;
        mSpassFingerprint = new SpassFingerprint(SampleActivity.this);

        mListView = (ListView)findViewById(R.id.listView1);
        mListAdapter = new ArrayAdapter<String>(this, R.layout.list_entry, mItemArray);
        mListView.setAdapter(mListAdapter);
        mSpass = new Spass();
        
        try {                    
            mSpass.initialize(SampleActivity.this);
        } catch (SsdkUnsupportedException e) {
            log("Exception: " + e);
        } catch (UnsupportedOperationException e){
            log("Fingerprint Service is not supported in the device");
        }
        isFeatureEnabled = mSpass.isFeatureEnabled(Spass.DEVICE_FINGERPRINT);
        
        SparseArray<View.OnClickListener> listeners = new SparseArray<View.OnClickListener>();

        listeners.put(R.id.buttonIsFeatureEnabled, new View.OnClickListener() {
            @Override
            public void onClick(View v) {                
                logClear();
                log("isFeatureEnabled(DEVICE_FINGERPRINT) = " + isFeatureEnabled);
            }
        });

        listeners.put(R.id.buttonHasRegisteredFinger, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
                try{
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else { 
                        boolean hasRegisteredFinger = mSpassFingerprint.hasRegisteredFinger();
                        log("hasRegisteredFinger() = " + hasRegisteredFinger);
                    }
                } catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });

        listeners.put(R.id.buttonIdentify, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
            	try{
            	    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else { 
                        if(!mSpassFingerprint.hasRegisteredFinger()){
                            log("Please register finger first");
                        } else {
        					if(onReadyIdentify == false){
        					    onReadyIdentify = true;
        	            		mSpassFingerprint.startIdentify(listener);
        	            		log("Please swipe finger to verify you");
        	                } else {
        	                    log("Please cancel Identify first");
        	            	}
                        }
                    }
            	} catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });

        listeners.put(R.id.buttonShowIdentifyDialogWithPW, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
                try{
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else {
                        if(!mSpassFingerprint.hasRegisteredFinger()){
                            log("Please register finger first");
                        } else {
        					if(onReadyIdentify == false){
        					    onReadyIdentify = true;
        	            		mSpassFingerprint.startIdentifyWithDialog(SampleActivity.this, listener,true);
        	            		log("Please swipe finger to verify you");
        	            	} else {
                                log("Please cancel Identify first");
        					}
                        }
                    }
                } catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });
        
        listeners.put(R.id.buttonShowIdentifyDialogWithoutPW, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
                try{
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else {
                        if(!mSpassFingerprint.hasRegisteredFinger()){
                            log("Please register finger first");
                        } else {
        					if(onReadyIdentify == false){
        					    onReadyIdentify = true;
        	            		mSpassFingerprint.startIdentifyWithDialog(SampleActivity.this, listener,false);
        	            		log("Please swipe finger to verify you");
        	            	}else{
        	            	    log("Please cancel Identify first");
        					}
                        }
                    }
                } catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });         

        listeners.put(R.id.buttonShowIdentifyDialogCancel, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
	            try {
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else {
                        if(!mSpassFingerprint.hasRegisteredFinger()){
                            log("Please register finger first");
                        } else {
        				    if(onReadyIdentify == false){
        				        onReadyIdentify = true;
        		                mSpassFingerprint.startIdentifyWithDialog(SampleActivity.this, listener, true);
        		                mListView.postDelayed(new Runnable() {
        		                    @Override
        		                    public void run() {
        		                        log("trying to cancel()");
        	
        		                        try {
        		                            mSpassFingerprint.cancelIdentify();
        		                            onReadyIdentify = false;
        		                        } catch (IllegalArgumentException e) {
        		                            log("cancel failed : " + e);
        		                        }
        		                    }
        	
        		                }, 2000);
        		            	} else {
        		            	    log("Please cancel Identify first");
        		            	}
        				    }
                        }
                    }catch (UnsupportedOperationException e){
	                    log("Fingerprint Service is not supported in the device");
	                }
            }
        });
        
        listeners.put(R.id.buttonCancel, new View.OnClickListener() {
            @Override
            public void onClick(View v) { 
                logClear();
                try{
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else {
    	            	if(onReadyIdentify == true){	            		
    		                mSpassFingerprint.cancelIdentify();
    		                log("cancelIdentify is called");
    		                onReadyIdentify = false;
    	            	}else {
    	            	    log("Please request Identify first");
                        }
					}
                } catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });       
        
        
        listeners.put(R.id.buttonRegisterFinger, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logClear();
                try{
                    if(!isFeatureEnabled){
                        log("Fingerprint Service is not supported in the device");
                    } else {
                        if(onReadyIdentify == false){                        
                            mSpassFingerprint.registerFinger(SampleActivity.this, mRegisterListener);
                            log("Jump to the Enroll screen");
                        } else {
                            log("Please cancel Identify first");
                        }
                    }
                } catch (UnsupportedOperationException e){
                    log("Fingerprint Service is not supported in the device");
                }
            }
        });
     
        final int N = listeners.size();

        for (int i=0; i<N; i++) {
            int id = listeners.keyAt(i);
            Button button = (Button)findViewById(id);
            button.setOnClickListener(listeners.valueAt(i));
            button.setTextAppearance(mContext, R.style.ButtonStyle);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void log(String text) {
        final String txt = text;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {                
                mItemArray.add(0, txt);
                mListAdapter.notifyDataSetChanged();
            }
        });
    }
    public void logClear(){ 
        if(mItemArray != null )
            mItemArray.clear();
            mListAdapter.notifyDataSetChanged();
    }
    
}
