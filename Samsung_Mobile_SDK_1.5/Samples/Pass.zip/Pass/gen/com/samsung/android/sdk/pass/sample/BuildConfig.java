/** Automatically generated file. DO NOT MODIFY */
package com.samsung.android.sdk.pass.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}