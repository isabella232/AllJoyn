cp /workspace/h-lte-MAIN-S/android/out/target/common/obj/JAVA_LIBRARIES/SPassSDK_intermediates/classes.jar libs/pass-v1.0.0.jar
