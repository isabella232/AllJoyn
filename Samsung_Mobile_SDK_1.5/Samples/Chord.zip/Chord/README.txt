Samsung Chord SDK --  Android Example
ChordSampleApp
============================================

## Build with Eclipse
Import this existing project into your Eclipse IDE (with ADT tooling).

## Build from the Shell
From the project root run
    ant -Dsdk.dir=<my sdk dir> release
