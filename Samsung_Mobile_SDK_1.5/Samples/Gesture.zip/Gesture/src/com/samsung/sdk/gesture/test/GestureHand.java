
package com.samsung.sdk.gesture.test;

import com.samsung.android.sdk.gesture.Sgesture;
import com.samsung.android.sdk.gesture.SgestureHand;
import com.samsung.android.sdk.gesture.SgestureHand.Info;

import android.os.Looper;

class GestureHand {
    private SgestureHand mGestureHand = null;

    GestureHand(Looper looper, Sgesture gesture) {
        mGestureHand = new SgestureHand(looper, gesture);
    }

    void start(int mode) {
        initialize();
        mGestureHand.start(mode, changeListener);
    }

    void stop() {
        initialize();
        mGestureHand.stop();
    }

    void initialize() {
        StringBuffer sb = new StringBuffer();
        sb.append("Ready");
        GestureTest.displayData(0, sb.toString());
    }

    private void displayData(Info info) {
        StringBuffer sb = new StringBuffer();
        long timestamp = System.currentTimeMillis();
        switch (info.getType()) {
            case Sgesture.TYPE_HAND_PRIMITIVE:
                int angle = info.getAngle();
                sb.append("Angle : " + angle + "\n");
                int speed = info.getSpeed();
                if (speed >= 0) {
                    sb.append("Speed : " + speed + "\n");
                }
                break;
        }
        GestureTest.displayData(timestamp, sb.toString());
    }

    private SgestureHand.ChangeListener changeListener = new SgestureHand.ChangeListener() {

        @Override
        public void onChanged(Info info) {
            // TODO Auto-generated method stub
            displayData(info);
        }
    };
}
