
package com.samsung.sdk.gesture.test;

import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.gesture.Sgesture;

import android.app.Activity;
import android.os.Bundle;
import android.os.Looper;
import android.text.format.Time;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.Formatter;

public class GestureTest extends Activity {

    private static final int MODE_HAND_PRIMITIVE = 0;

    private int mTestMode = MODE_HAND_PRIMITIVE;

    private GestureHand mGestureHand;

    private static TextView sTv_timestamp = null;

    private static TextView sTv_result = null;

    private boolean mIsTesting = false;

    private Spinner mSpin = null;

    private ToggleButton mBtn_start = null;

    private Sgesture mGesture;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (initialize()) {
            mBtn_start.setEnabled(true);
            mSpin.setClickable(true);

        } else {
            GestureTest.displayData(0, "Not Supported");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopGestureTest();
    }

    private boolean initialize() {

        // TextView
        sTv_timestamp = (TextView)findViewById(R.id.res_timestamp);
        sTv_result = (TextView)findViewById(R.id.res_result);

        // Sgesture initialize
        mGesture = new Sgesture();
        try {
            mGesture.initialize(this);
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } catch (SsdkUnsupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }

        // ToggleButton Start/Stop
        mBtn_start = (ToggleButton)findViewById(R.id.toggle_start);
        mBtn_start.setEnabled(false);
        mBtn_start.setOnClickListener(new ToggleButton.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Perform action on clicks
                if (mBtn_start.isChecked()) {
                    startGestureTest();
                } else {
                    stopGestureTest();
                }
            }
        });

        // Spinner
        mSpin = (Spinner)findViewById(R.id.spinner_mode);
        mSpin.setEnabled(false);
        mSpin.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position,
                    long data) {
                // TODO Auto-generated method stub
                mTestMode = position;
                switch (mTestMode) {
                    case MODE_HAND_PRIMITIVE:
                        if (!mGesture.isFeatureEnabled(Sgesture.TYPE_HAND_PRIMITIVE)) {
                            GestureTest.displayData(0, "Not Supported");
                            mBtn_start.setEnabled(false);
                            mSpin.setEnabled(true);
                        } else {
                            mSpin.setEnabled(true);
                            mBtn_start.setEnabled(true);
                            if (mGestureHand == null) {
                                mGestureHand = new GestureHand(Looper.getMainLooper(), mGesture);
                                sTv_timestamp.setVisibility(View.VISIBLE);
                                sTv_result.setVisibility(View.VISIBLE);
                                mGestureHand.initialize();
                            }
                        }
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub
            }
        });

        return true;
    }

    private void startGestureTest() {
        mIsTesting = true;
        mSpin.setEnabled(false);

        switch (mTestMode) {
            case MODE_HAND_PRIMITIVE:
                mGestureHand.start(MODE_HAND_PRIMITIVE);
                break;
        }
    }

    private void stopGestureTest() {
        if (mIsTesting) {
            mIsTesting = false;
            mSpin.setEnabled(true);
            switch (mTestMode) {
                case MODE_HAND_PRIMITIVE:
                    mGestureHand.stop();
                    break;
            }
        }
    }

    static void displayData(long timestamp, String str) {
        if (sTv_timestamp.getVisibility() == View.VISIBLE) {
            if (timestamp == 0) {
                sTv_timestamp.setText("[00:00:00]");
            } else {
                Time time = new Time();
                time.set(timestamp);
                Formatter form = new Formatter();
                form.format("%02d:%02d:%02d", time.hour, time.minute, time.second);
                sTv_timestamp.setText(new StringBuffer("[").append(form.toString()).append("]")
                        .toString());
                form.close();
            }
        }
        if (sTv_result.getVisibility() == View.VISIBLE) {
            sTv_result.setText(new StringBuffer(str).toString());
        }
    }

}
