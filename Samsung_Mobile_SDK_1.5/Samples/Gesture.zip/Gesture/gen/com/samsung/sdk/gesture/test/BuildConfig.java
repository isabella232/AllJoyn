/** Automatically generated file. DO NOT MODIFY */
package com.samsung.sdk.gesture.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}